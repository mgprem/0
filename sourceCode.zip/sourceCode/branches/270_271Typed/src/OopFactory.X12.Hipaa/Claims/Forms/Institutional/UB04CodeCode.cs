﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OopFactory.X12.Hipaa.Claims.Forms.Institutional
{
    public class UB04CodeCode
    {
        public string Qualifier { get; set; }
        public string Code1 { get; set; }
        public string Code2 { get; set; }
    }
}
